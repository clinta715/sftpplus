import sys
import os
import subprocess
import random
import string
import smtplib
import shutil
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def generate_random_string(length=8):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def read_smtp_config(log_file_name):
    try:
        with open("smtp.txt", "r") as f:
            smtp_server = f.readline().strip()
            dest_email = f.readline().strip()
            source_email = f.readline().strip()
            base_work_path = f.readline().strip()
    except FileNotFoundError:
        with open(log_file_name, "a") as log:
            log.write(f"Error: smtp.txt not found\n")
        print(f"Error: smtp.txt not found")
        exit(1)

    return smtp_server, dest_email, source_email, base_work_path

def send_email(smtp_server, source_email, dest_email, log_file_name, subject, body):
    msg = MIMEMultipart()
    msg['From'] = source_email
    msg['To'] = dest_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    if log_file_name:
        with open(log_file_name, 'rb') as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload((attachment).read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', "attachment; filename= %s" % os.path.basename(log_file_name))
            msg.attach(part)

    try:
        server = smtplib.SMTP(smtp_server)
        server.sendmail(source_email, dest_email, msg.as_string())
        server.quit()
        print(f"Email sent successfully to {dest_email}")
    except Exception as e:
        print(f"Failed to send email. Error: {e}")
        with open(log_file_name, "a") as log:
            log.write(f"Failed to send email. Error: {e}\n")

def send_success_email(smtp_server, source_email, dest_email):
    subject = "Script Completed Successfully"
    body = "The script completed successfully without any errors."

    send_email(smtp_server, source_email, dest_email, None, subject, body)

def main():
    if len(sys.argv) < 3:
        print("Usage: python your_script.py source_path destination_path")
        sys.exit(1)

    base_path = sys.argv[1]
    tape_path = sys.argv[2]

    temp_folder_name = f"{os.path.basename(__file__)[:-3]}_{generate_random_string()}"
    log_file_name = f"/tmp/{os.path.basename(__file__)[:-3]}_{generate_random_string()}.log"
    smtp_server, dest_email, source_email, base_work_path = read_smtp_config(log_file_name)

    print(f"Using SMTP server: {smtp_server}")
    print(f"Destination Email: {dest_email}")
    print(f"Source Email: {source_email}")
    print(f"Base Work Path: {base_work_path}")
    print(f"Temporary Folder Name: {temp_folder_name}")
    print(f"Log File Name: {log_file_name}")

    try:
        # Process .sync files
        for sync_file in os.listdir(base_path):
            if sync_file.endswith(".tape"):
                lockfile = f"/tmp/{os.path.basename(sync_file)}.lock"
                print(f"Lockfile {lockfile}")
                source_archive = sync_file[:-5]

                if os.path.exists(lockfile):
                    print(f"Error: Lockfile {lockfile} already exists. Skipping.")
                    with open(log_file_name, "a") as log:
                        log.write(f"Error: Lockfile {lockfile} already exists. Skipping.\n")
                    continue

                with open(lockfile, "w") as lock:
                    lock.write(str(os.getpid()))

                try:
                    print(f"Copying {source_archive}...")
                    shutil.copy( os.path.join(base_path, source_archive), os.path.join(tape_path, source_archive) )
                except:
                    print(f"Error: Error copying {source_archive}")
                    with open(log_file_name, "a") as log:
                        log.write(f"Error: Error copying {source_archive}\n")

                os.remove(lockfile)
    except Exception as e:
        with open(log_file_name, "a") as log:
            log.write(f"Error: {e}\n")
        print(f"Error: {e}")
        send_email(smtp_server, source_email, dest_email, log_file_name, "Script Error", f"Error: {e}")
    else:
        send_success_email(smtp_server, source_email, dest_email)

if __name__ == "__main__":
    main()
