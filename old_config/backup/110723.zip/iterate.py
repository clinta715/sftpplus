import sys
import os
import subprocess
import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase

def generate_random_string(length=8):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def read_smtp_config(log_file_name):
    try:
        with open("smtp.txt", "r") as f:
            smtp_server = f.readline().strip()
            dest_email = f.readline().strip()
            source_email = f.readline().strip()
            base_work_path = f.readline().strip()
    except FileNotFoundError:
        print("Error: smtp.txt not found")
        with open(log_file_name, "a") as log:
            log.write(f"Error: smtp.txt not found\n")
        exit(1)

    return smtp_server, dest_email, source_email, base_work_path

def send_email(smtp_server, source_email, dest_email, log_file_name, subject, body):
    msg = MIMEMultipart()
    msg['From'] = source_email
    msg['To'] = dest_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    if log_file_name:
        with open(log_file_name, 'rb') as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload((attachment).read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', "attachment; filename= %s" % os.path.basename(log_file_name))
            msg.attach(part)

    try:
        server = smtplib.SMTP(smtp_server)
        server.sendmail(source_email, dest_email, msg.as_string())
        server.quit()
        print(f"Email sent successfully to {dest_email}")
    except Exception as e:
        print(f"Failed to send email. Error: {e}")
        with open(log_file_name, "a") as log:
            log.write(f"Failed to send email. Error: {e}\n")

def send_success_email(smtp_server, source_email, dest_email):
    subject = "Script Completed Successfully"
    body = "The script completed successfully without any errors."

    send_email(smtp_server, source_email, dest_email, None, subject, body)

def main():
    base_path = sys.argv[1]
    output_path = sys.argv[2]

    temp_folder_name = f"{base_work_path}/{os.path.basename(__file__)[:-3]}_{generate_random_string()}"
    log_file_name = f"/tmp/{os.path.basename(__file__)[:-3]}_{generate_random_string()}.log"
    smtp_server, dest_email, source_email, base_work_path = read_smtp_config(log_file_name)

    print(f"Using SMTP server: {smtp_server}")
    print(f"Destination Email: {dest_email}")
    print(f"Source Email: {source_email}")
    print(f"Base Work Path: {base_work_path}")
    print(f"Temporary Folder Name: {temp_folder_name}")
    print(f"Log File Name: {log_file_name}")

    try:
        # Process .backup files
        for sync_file in os.listdir(base_path):
            if sync_file.endswith(".backup"):
                with open(os.path.join(base_path, sync_file), "r") as f:
                    source_host = f.readline().strip()
                    source_path = f.readline().strip()
                    dest_archive = f.readline().strip()
                    resulting_path = os.path.join(output_path, dest_archive)
                    vm_number = f.readline().strip()

                lockfile = f"/tmp/{os.path.basename(dest_archive)}.lock"

                if os.path.exists(lockfile):
                    print(f"Error: Lockfile {lockfile} already exists. Skipping.")
                    with open(log_file_name, "a") as log:
                        log.write(f"Error: Lockfile {lockfile} already exists. Skipping.\n")
                    continue
                else:
                    with open(lockfile, "w") as locko:
                        locko.write(str(os.getpid()))

                # create snapshot of vm first

                print(f"Creating snapshot for VM {vm_number} on host {source_host}...")
                snapshot_command = f'ssh root@{source_host} "vim-cmd vmsvc/snapshot.create {vm_number} BackupSnapshot SnapshotBackup 0 1"'
                subprocess.run(snapshot_command, shell=True, check=True)

                mount_path = os.path.join(base_work_path, temp_folder_name)

                os.makedirs(mount_path, exist_ok=True)

                print(f"Mounting {source_path} to {mount_path}...")
                sshfs_command = f"sshfs root@{source_host}:{source_path} {mount_path}"
                subprocess.run(sshfs_command, shell=True)

                try:
                    print(f"Creating archive {dest_archive}...")
                    find_command = f'find {mount_path} -type f \( -name "*.vmdk" -o -name "*.vmx" -o -name "*.vmxf" -o -name "*.vmsd" \) -not \( -name "*00000*" -o -name "*sesparse*" \) -print'
                    tar_command = f'{find_command} | tar --use-compress-program=zstd -cvf {resulting_path} -T -'
                    print(tar_command)
                    subprocess.run(tar_command, shell=True, check=True)
                finally:
                    print(f"Unmounting {source_path}...")
                    unmount_command = f"fusermount -u {mount_path}"
                    subprocess.run(unmount_command, shell=True)

                print(f"Removing snapshots for VM {vm_number} on host {source_host}...")
                snapshot_remove_command = f'ssh root@{source_host} "vim-cmd vmsvc/snapshot.removeall {vm_number}"'
                subprocess.run(snapshot_remove_command, shell=True, check=True)

                os.remove(lockfile)
    except Exception as e:
        with open(log_file_name, "a") as log:
            log.write(f"Error: {e}\n")
            print(f"Error: {e}")
            send_email(smtp_server, source_email, dest_email, log_file_name, "Script Error", f"Error: {e}")
    else:
        send_success_email(smtp_server, source_email, dest_email)

if __name__ == "__main__":
    main()
